/*
 * chris_s_functions.h
 *
 *  Created on: Mar 13, 2016
 *      Author: chris
 */

#ifndef P3_CHRIS_S_FUNCTIONS_H_
#define P3_CHRIS_S_FUNCTIONS_H_

#include "p3_globals.h"

void	P3_Fork(int pid);
void	P3_Switch(int old, int new);

#endif /* P3_CHRIS_S_FUNCTIONS_H_ */
